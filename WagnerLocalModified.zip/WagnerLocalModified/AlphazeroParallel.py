import numpy as np
import random
import math
#print(np.__version__)
import torch
#print(torch.__version__)
import torch.nn as nn
import torch.nn.functional as F
import time
# torch.manual_seed(0)

from tqdm import trange

from MCTSParallel import MCTSParallel
# from NodeWagner import Node

class AlphaZeroParallel:
    def __init__(self, model, optimizer, game, args):
        """
        Initialize the AlphaZero agent with a neural network model, optimizer, game environment, and hyperparameters.

        Args:
            model: The neural network model to be used for policy and value estimation.
            optimizer: The optimizer to update the model weights.
            game: The game environment to play in.
            args: A dictionary containing hyperparameters for the algorithm.
        """
        self.model = model
        self.optimizer = optimizer
        self.game = game
        self.args = args
        self.mcts = MCTSParallel(game, args, model)
        self.value_losses = []  # List to store value losses
        self.policy_losses = []
        self.game_idx = 0
        
    def selfPlay(self):
        """
        Perform self-play games and collect data for training.

        Returns:
            A list of transitions (encoded state, policy probabilities, outcome) collected during self-play.
        """
        return_memory = []
        player = 0
        spGames = [SPG(self.game) for spg in range(self.args['num_parallel_games'])]
        block = -1
        while len(spGames) > 0:
            neutral_states = np.stack([spg.state for spg in spGames])
            #print(f"neutral states stack {neutral_states}")
            #print(f"Dimension of np.stack {neutral_states.shape}")
            #neutral_states = self.game.change_perspective(states, player)
            block +=1
            print(f"Start searches = {block}")
            start_time = time.time()
            self.mcts.search(neutral_states, spGames)
            end_time = time.time()
            execution_time = end_time - start_time
            print(f"Execution time for a search block = {execution_time}")
            for i in range(len(spGames))[::-1]:
                spg = spGames[i]
                action_probs = np.zeros(self.game.action_size)
                for child in spg.root.children:
                    action_probs[child.action_taken] = child.visit_count
                action_probs /= np.sum(action_probs)

                #print(f"action probs = {action_probs}")

                spg.memory.append((spg.root.state, action_probs))

                if self.game_idx < self.args['temperature_iterations']:
                    temp = self.args['temperature']
                else:
                    temp = 1

                temperature_action_probs = action_probs ** (1 / temp)
                
                #actions = np.random.choice(self.game.action_size, size=self.args['batch_actions'], replace=False, p=normalized_probs)
                action = np.random.choice(self.game.action_size, p=temperature_action_probs/np.sum(temperature_action_probs))
                spg.state = self.game.get_next_state(spg.state, action, player)
                value, is_terminal = self.game.get_value_and_terminated(spg.state, action)

                if is_terminal:
                    for hist_neutral_state, hist_action_probs in spg.memory:
                        hist_outcome = value #if hist_player == player else self.game.get_opponent_value(value)
                        return_memory.append((
                            self.game.get_encoded_state(hist_neutral_state),
                            hist_action_probs,
                            hist_outcome
                        ))
                    del spGames[i]
        self.game_idx += 1
                   
            #player = self.game.get_opponent(player)
            
        return return_memory
                
    def train(self, memory):
        random.shuffle(memory)
        for batchIdx in range(0, len(memory), self.args['batch_size']):
            #print(f"Batch ={batchIdx}")
            #sample = memory[batchIdx:batchIdx+self.args['batch_size']]
            sample = memory[batchIdx:min(len(memory) - 1, batchIdx + self.args['batch_size'])] # Change to memory[batchIdx:batchIdx+self.args['batch_size']] in case of an error
            #print(f"Sample size ={len(sample)}")
            state, policy_targets, value_targets = zip(*sample)
            #print(f"state len after zip ={len(state)}")
            state, policy_targets, value_targets = np.array(state), np.array(policy_targets), np.array(value_targets).reshape(-1, 1)
            #print(f"state len after np ={len(state)}")
            #print(f"state after np ={state}")
            state = torch.tensor(state, dtype=torch.float32, device=self.model.device)
            #print(f"state size = {state.size()}")
            policy_targets = torch.tensor(policy_targets, dtype=torch.float32, device=self.model.device)
            value_targets = torch.tensor(value_targets, dtype=torch.float32, device=self.model.device)
            
            out_policy, out_value = self.model(state)
            
            policy_loss = F.cross_entropy(out_policy, policy_targets)
            value_loss = F.mse_loss(out_value, value_targets)
            loss = policy_loss + value_loss

            self.policy_losses.append(policy_loss.item())
            self.value_losses.append(value_loss.item())
            
            self.optimizer.zero_grad()
            loss.backward()
            self.optimizer.step()

    def save_losses(self, filename_prefix):
        torch.save({'policy_losses': self.policy_losses, 'value_losses': self.value_losses}, f"{filename_prefix}_losses.pt")

    def learn(self):
        for iteration in range(self.args['num_iterations']):
            memory = []
            print(f"Iteration ={iteration}")
           
            self.model.eval()
            for selfPlay_iteration in trange(self.args['num_selfPlay_iterations'] // self.args['num_parallel_games']):
                print(f" Self_play_iteration = {selfPlay_iteration}")
                memory += self.selfPlay()
                
            self.model.train()
            for epoch in trange(self.args['num_epochs']):
                print(f"Epoch = {epoch}")
                self.train(memory)
            
            torch.save(self.model.state_dict(), f"model_{iteration}_{self.game}_{self.game.number_of_nodes}.pt")
            torch.save(self.optimizer.state_dict(), f"optimizer_{iteration}_{self.game}_{self.game.number_of_nodes}.pt")
            self.save_losses(f"model_{iteration}_{self.game}_{self.game.number_of_nodes}")
            
class SPG:
    def __init__(self, game):
        self.state = game.get_initial_state()
        self.memory = []
        self.root = None
        self.node = None