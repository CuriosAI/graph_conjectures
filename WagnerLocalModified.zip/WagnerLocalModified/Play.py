import numpy as np
import random
import math
print(np.__version__)
import torch
print(torch.__version__)
import torch.nn as nn
import torch.nn.functional as F
import matplotlib.pyplot as plt
#torch.manual_seed(0)
from tqdm import trange
import networkx as nx

from MCTS import MCTS

from WagnerEnv import WagnerLin
from BrouwerGlobal import BrouwerGlobal
from Resnet import ResNet

""" This code implements a Reinforcement Learning algorithm to test the First Wagner's conjecture. 
It uses a neural network-based model to evaluate the state of the game and an AlphaZero-like Monte-Carlo Tree Search (MCTS) algorithm to make decisions."""

# Create an instance of the WagnerLin game class
game = WagnerLin(18)
#game = BrouwerGlobal(11)
# Set the player to 0
player = 0

args = {
    # Exploration parameter for the MCTS algorithm
    'C': 2,
    # Number of MCTS simulations per move
    'num_searches': 100,
    # Dirichlet noise for selecting initial exploration moves
    'dirichlet_epsilon': 0.05,
    # Dirichlet noise parameter
    'dirichlet_alpha': 0.3,
    'pruning_threshold': 0.0
}
# Set the device (CPU or GPU)
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
# Load the neural network model
model = ResNet(game, 6, 64, device)
# Load the trained model parameters
#model.load_state_dict(torch.load("model_0.pt", map_location=device))
model.load_state_dict(torch.load("model_0_WagnerLin_18.pt", map_location=device))
#model.load_state_dict(torch.load("model_2_BrouwerGlobal_13.pt", map_location=device))
# model.load_state_dict(torch.load(f"model_{number_of_nodes}.pt", map_location=device))
# Set the model to evaluation mode
model.eval()
# Create an instance of the MCTS algorithm
mcts = MCTS(game, args, model)

# Start the game with an empty board
state = game.get_initial_state()

#graph = nx.from_numpy_array(state)
#nx.draw(graph, with_labels = True)
#plt.show()
best_score = -np.Inf
best_state = game.get_initial_state()
with open(f"Game_{game.__repr__()}_{game.number_of_nodes}.txt", "w") as file:
    while True:
        print(state)
        file.write(f"State: {state} s \n")
    #graph = nx.from_numpy_array(state)
    #nx.draw(graph, with_labels = True)
    #plt.show()
        score = game.score(state)
        if score > best_score:
            best_score = score
            best_state = state
        print(f"Plain score = {game.score(state)}")
        file.write(f"Plain score: {game.score(state)} s \n")
        mcts_probs = mcts.search(state)
    #print(mcts_probs)
    # Selects the move based on the highest probability
        action = np.argmax(mcts_probs)
        row,col =game.get_action_row_col(action)
        file.write(f"Action {action} ----> remove edge ({row},{col}) \n")
    # Update the game state with the selected move
        state = game.get_next_state(state, action, player)
        file.write(f"New state: {state} s \n")
    # Checks the game status and winner
        value, is_terminal = game.get_value_and_terminated(state, action)
        file.write(f"Value = {value}, is_terminal = {is_terminal}) \n")
        if is_terminal:
        # Prints the final board
            print(state)
            print(game.score(state))
            if value == 1:
                print("Counterexample found")
            else:
                print("Counterexample not found")
            break
    file.write(f"Best score {best_score} \n")
    file.write(f"Best state {best_state} \n")
    file.close()
graph = nx.from_numpy_array(state)
nx.draw(graph, with_labels = True)
plt.show()