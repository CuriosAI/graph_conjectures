import numpy as np
import random
import math
import torch
import torch.nn as nn
import torch.nn.functional as F
import time
import datetime
#torch.manual_seed(0)
from tqdm import trange

from AlphazeroParallel import AlphaZeroParallel
from WagnerEnv import WagnerLin
from Resnet import ResNet
from BrouwerGlobal import BrouwerGlobal

def main():
    game = WagnerLin(7)
    #game = BrouwerGlobal(11)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(device)
    num_resBlocks = 7
    num_hidden = 128
    model = ResNet(game, num_resBlocks, num_hidden, device)
    optimizer = torch.optim.Adam(model.parameters(), lr=0.001, weight_decay=0.0001)

    args = {
        'C': 2,
        'num_searches': 100,
        'num_iterations': 10,
        'num_selfPlay_iterations': 50,
        'num_parallel_games': 50,
        'num_epochs': 5,
        'batch_size': 100,
        'temperature': 1.25,
        'dirichlet_epsilon': 0.05,
        'dirichlet_alpha': 0.3, 
        'temperature_iterations': 30,
        'pruning_threshold': 0.0
    }

    alphaZero = AlphaZeroParallel(model, optimizer, game, args)
    start_time = time.time()
    alphaZero.learn()
    end_time = time.time()
    execution_time = end_time - start_time
    current_time = datetime.datetime.now()
    with open(f"{game.__repr__()}_{current_time.day}_{current_time.hour}_{current_time.minute}_execution_time_{game.number_of_nodes}.txt", "w") as file:  # Usa "a" per appendere o "w" per sovrascrivere
        file.write(f"Execution_time: {execution_time} s \n")
        file.write(f"number_of_nodes : {game.number_of_nodes} \n")
        file.write(f"num_res_blocks = {num_resBlocks}\n")
        file.write(f"self.stop_threshold = {game.stop_threshold}\n")
        file.write(f"num_hidden = {num_hidden}\n")
        file.write(f"C = {args['C']} \n")
        file.write(f"num_searches = {args['num_searches']} \n")
        file.write(f"num_iterations = {args['num_iterations']} \n")
        file.write(f"num_selfPlay_iterations = {args['num_selfPlay_iterations']} \n")
        file.write(f"num_parallel_games = {args['num_parallel_games']} \n")
        file.write(f"num_epochs = {args['num_epochs']} \n")
        file.write(f"batch_size = {args['batch_size']} \n")
        file.write(f"temperature = {args['temperature']} \n")
        file.write(f"dirichlet_epsilon = {args['dirichlet_epsilon']} \n")
        file.write(f"dirichlet_alpha = {args['dirichlet_alpha']} \n")
        file.write(f"pruning_threshold = {args['pruning_threshold']} \n")
        file.close()

if __name__ == '__main__':
    main()