import numpy as np
import random
import math
#print(np.__version__)
import torch
#print(torch.__version__)
import torch.nn as nn
import torch.nn.functional as F
import networkx as nx

from tqdm.notebook import trange

class WagnerLin:
    def __init__(self, number_of_nodes, dense_reward=False, penalize_star=False):
        #self.action_size = number_of_nodes * number_of_nodes
        self.action_size = number_of_nodes * (number_of_nodes -1)//2
        self.number_of_nodes = number_of_nodes
        self.row_count = number_of_nodes
        self.column_count = number_of_nodes
        self.number_of_edges = number_of_nodes * (number_of_nodes -1)//2
        self.episode_number = 0
        self.total_steps = 0
        self.best_score = -np.Inf
        self.dense_reward = dense_reward
        self.penalize_star = penalize_star
        self.nxstar = nx.star_graph(self.number_of_nodes-1)
        player = 0
        self.last_score = 0
        self.stop_threshold = 0.8
        
    def __repr__(self):
        return "WagnerLin"
        
    def get_initial_state(self):
        initial_state = np.ones((self.number_of_nodes, self.number_of_nodes))
        initial_state -= np.eye(self.number_of_nodes)
        initial_state = np.triu(initial_state)
        self.episode_number = self.episode_number + 1
        self.graph = np.ones(self.number_of_edges, dtype=np.int8)
        self.last_score = self.score(initial_state)
        self.last_reward = 0
        self.last_score = self.score(initial_state)
        self.best_score_in_episode = -np.Inf
        return initial_state
    
    def check_connectivity(self, state):
        return nx.is_connected(nx.from_numpy_array(state))
    
    def get_action_row_col(self, action):
    # Calculate the total number of nodes
        n = self.number_of_nodes
    # Determine the row based on the action
        row = 0
    # Calculate the maximum action index for the current row
        max_action_for_row = n - 1  # The last possible action index in the first row
        while action >= max_action_for_row:
            row += 1
            max_action_for_row += (n - row - 1)
    # Calculate the column based on the row and action
        col_offset = action - (max_action_for_row - (n - row - 1))
        column = row + 1 + col_offset
        return row, column
    
    def get_next_state(self, state, action, player):
        self.last_score = self.score(state)
    # Implement the custom mapping from action index to (row, column)
        row, column = self.get_action_row_col(action)
    # Update the state with the player's action
        state[row, column] = player
        return state

    def get_valid_moves_old(self, state):
        n = len(state)
        valid_moves = np.zeros((n, n))
        edges = [(i, j) for i in range(n) for j in range(n) if i < j and state[i][j] == 1]
        for i, j in edges:
            state[i][j] = 0  # Remove the edge
            if self.check_connectivity(state):
                valid_moves[i][j] = 1
            state[i][j] = 1  # Restore the edge
        valid_moves = np.array(valid_moves)
        r, c = np.triu_indices_from(valid_moves, k=1)
        upper_triangular_array = valid_moves[r, c]
    
        return upper_triangular_array.astype(np.uint8)
    
    def get_valid_moves(self, state):
        n = len(state)
        valid_moves = np.zeros((n, n), dtype=int)
        state = np.array(state, dtype=int)  # Ensure numpy array for efficient operations

        # Find all existing edges in the upper triangle
        edges = np.transpose(np.triu_indices(n, 1))
        edges = edges[state[edges[:,0], edges[:,1]] == 1]

        # Test removal of each edge
        for i, j in edges:
            state[i, j] = state[j, i] = 0  # Remove the edge
            if self.check_connectivity(state):
                valid_moves[i, j] = 1
            state[i, j] = state[j, i] = 1  # Restore the edge

        return valid_moves[np.triu_indices(n, 1)].astype(np.uint8)
    
        #return valid_moves

    def score(self, state):
        graph = nx.from_numpy_array(state)
        constant = 1 + np.sqrt(len(graph.nodes) - 1)
        lambda_1 = max(np.real(nx.adjacency_spectrum(graph)))
        mu = len(nx.max_weight_matching(graph,maxcardinality=True))
        score = constant - (lambda_1 + mu)
        return score
    
    def check_win(self, state, action):
        if self.score(state) > 1e-12:
            return True
        else: 
            return False
        
    def get_value_and_terminated(self, state, action):
        score = self.score(state)
        if score >  1e-12:
            return score, True
        else:
            if np.sum(self.get_valid_moves(state)) == 0 or (self.last_score - score > self.stop_threshold):
                return score, True
            else:
                return score, False
    
    # The get_encoded_state method converts the current game state (represented as a NumPy array) into a format suitable for input to a neural network.
    # Note that for other applications the number of stacked planes should be modified.'''
    
    def get_encoded_state(self, state):
        encoded_state = np.stack((state == 0, state == 1)).astype(np.float32)
        # This is needed in case of parallel execution of Alphazero
        #print(f"encoded state before swap = {encoded_state}")
        #print(f"encoded state len = {len(encoded_state)}")
        if len(state.shape) == 3:
            encoded_state = np.swapaxes(encoded_state, 0, 1)
        #print(f"encoded state after swap = {encoded_state}")
        return encoded_state
